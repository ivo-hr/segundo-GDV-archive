#include "Rock.h"
#include "../Game.h"


bool Rock::receiveCarCollision(Car* car) {
   // TODO
    return false;
}

