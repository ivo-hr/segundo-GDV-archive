#include "PowerUp.h"

#include "../Game.h"

bool PowerUp::receiveCarCollision(Car* car) {
    // TODO
    return false;
}