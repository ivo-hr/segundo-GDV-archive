﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel.DataTransfer;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0xc0a

namespace P4
{
    /// <summary>
    /// Página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public DataPackageOperation AcceptedOperation { get; set; }
        public DataPackageView DataView { get; }
        public ObservableCollection<VMDron> ListaDrones { get; } = new ObservableCollection<VMDron>();


        private TranslateTransform dragTrans;
        public MainPage()
        {
            this.InitializeComponent();

            dragTrans = new TranslateTransform();
            MiDron.RenderTransform = this.dragTrans;
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            // Cosntruye las listas de ModelView a partir de la lista Modelo 
            if (ListaDrones != null)
                foreach (Dron dron in Model.GetAllDrones())
                {
                    VMDron VMitem = new VMDron(dron);
                    ListaDrones.Add(VMitem);
                }
            base.OnNavigatedTo(e);
        }

        private void Canv_DragOver(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = DataPackageOperation.Copy;
        }

        private async void Canv_Drop(object sender, DragEventArgs e)
        {
            var id = await e.DataView.GetTextAsync();
            var number = int.Parse(id);
            MiDron.Source = ListaDrones[number].Img.Source;
            Point pos = e.GetPosition(MiMapa);
            MiDron.SetValue(Canvas.LeftProperty, pos.X - 25);
            MiDron.SetValue(Canvas.TopProperty, pos.Y - 25);
            MiDron.Visibility = Visibility.Visible;
        }

        private void ImageGridView_DragItemsStarting(object sender, DragItemsStartingEventArgs e)
        {
            VMDron Item = e.Items[0] as VMDron;
            string id = Item.Id.ToString();
            e.Data.SetText(id);
            e.Data.RequestedOperation = DataPackageOperation.Copy;
        }
    }
}
